#bash
echo "scrip exec started ... "
touch test.txt
echo "scrip executed "
